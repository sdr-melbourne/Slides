#!/usr/bin/perl

# send:
#   hackrf_transfer -t foo.cs8 -f 432750000 -a 0 -p 0 -x 10 -s 20000000
# recv (in rfcat):
#   d.setFreq(433000000)
#   d.makePktFLEN(10)
#   d.setMdmDRate(300)
#   d.RFlisten()

$preamble = pack("H*", "AAAAAAAA0C4E"); # hex representation of the preamble and sync word
$message = $preamble . "w00t! XMIT";    # full message is the binary preamble plus ASCII content
$message_bits = unpack("B*", $message); # unpack binary message into a string of "10101010....."

$sample_rate = 20000000;                # transmit sample rate
$center_frequency = 432750000;          # tuned frequency of the transmitter
$signal_frequency = 433000000;          # frequency at which the signal will appear
$signal_deviation = 20507;              # the 2FSK deviation of "0" and "1" bit frequencies
$signal_rate = 300;                     # symbol rate (baud rate) of the packet transmission

$twopi = 6.28318530717959;
$samples_per_bit = int($sample_rate / $signal_rate);    # number of samples to transmit for each symbol
$theta_inc[0] = ($signal_frequency - $center_frequency - $signal_deviation)*$twopi/$sample_rate; # rad/sample
$theta_inc[1] = ($signal_frequency - $center_frequency + $signal_deviation)*$twopi/$sample_rate; # rad/sample

$theta = 0;
$amplitude = 100;       # full-range for HackRF is (-127,128), 100 is nice and strong without clipping
foreach $bit (split //, $message_bits) {        # each bit in the message
  for ($n = 0; $n < $samples_per_bit; $n++) {   # each sample in the bit
    $theta += $theta_inc[$bit];                 # move around the origin by the right amount for this symbol
    $I = $amplitude * cos($theta);              # find in-phase (I) value
    $Q = $amplitude * sin($theta);              # find quadrature (Q) value
    print pack("cc", int($I), int($Q));         # pack into 2 unsigned chars, write to output
  }
}
